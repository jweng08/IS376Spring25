import React, { useState } from "react";

function App() {
  const [jobTitle, setJobTitle] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuggestions([]);

    try {
      // POST request to send job title
      await fetch("http://127.0.0.1:8000/job-posting", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: jobTitle }),
      });

      // GET request to retrieve job suggestions
      const response = await fetch(
        "http://127.0.0.1:8000/job-suggestions?index=0"
      );
      if (!response.ok) throw new Error("Failed to search!");

      const data = await response.json();
      const jobs = data.suggestions
        .split("\n")
        .map((job) => job.trim())
        .filter((job) => job !== "");

      setSuggestions(jobs);
    } catch (err) {
      setError("Errorrrrrrrrrrrrrrrrr!!!");
      console.error(err);
    }
  };

  return (
    <div style={{ padding: "2rem", fontFamily: "Arial, sans-serif" }}>
      <h2>Job Post Suggestions</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={jobTitle}
          onChange={(e) => setJobTitle(e.target.value)}
          placeholder="Search Job Post (e.g Software Engineer)"
          required
          style={{ padding: "0.5rem", width: "300px" }}
        />
        <button type="submit" style={{ marginLeft: "1rem", padding: "0.5rem" }}>
          Search
        </button>
      </form>

      {error && <p style={{ color: "red" }}>{error}</p>}

      {suggestions.length > 0 && (
        <div style={{ marginTop: "2rem" }}>
          <h3>Similar Job Post</h3>
          <ul className="no-bullets">
            {suggestions.map((title, index) => (
              <li key={index}> {title}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
export default App;
